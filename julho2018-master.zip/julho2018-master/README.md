# julho2018
Newsletter de 2018
